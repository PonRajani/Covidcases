package com.cst2335.finalproject.adapters;

public class DataAdapter {
}
