package com.cst2335.finalproject.models;

public class Data {
}
