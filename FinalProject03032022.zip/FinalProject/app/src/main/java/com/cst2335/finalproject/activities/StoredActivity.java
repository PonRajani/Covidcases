package com.cst2335.finalproject.activities;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.database.Cursor;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.cst2335.finalproject.R;
import com.cst2335.finalproject.databases.DatabaseHandler;
import com.cst2335.finalproject.fragment.CovidResultByDateFragment;
import com.google.android.material.navigation.NavigationView;

import java.util.ArrayList;

public class StoredActivity extends AppCompatActivity {

    SQLiteDatabase db;
    ArrayList<String> dateList = new ArrayList<>();
    CovidDateListAdaptor covidDateListAdaptor;
    CovidResultByDateFragment dFragment;
    public static final String DATE = "DATE";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stored);

        Toolbar tBar = (Toolbar) findViewById(R.id.covidToolbar);

        //This loads the toolbar, which calls onCreateOptionMev
        setSupportActionBar(tBar);

        // for Navigation Drawer
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this,
                drawer, tBar, R.string.open, R.string.close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener (item -> {

            switch (item.getItemId()) {
                // when the menu item is selected go to view history page.
                case R.id.navigation_view_history_item:
                    Intent viewHistory = new Intent(this, StoredActivity.class);
                    startActivity(viewHistory);
                    break;

                case R.id.navigation_search_item:
                    Intent covidSearch = new Intent(this, MainActivity.class);
                    startActivity(covidSearch);
                    break;

            }

            DrawerLayout drawerLayout = findViewById(R.id.drawer_layout);
            drawerLayout.closeDrawer(GravityCompat.START);
            return true;
        });

        ListView myList = findViewById(R.id.searchListView);
        boolean isTablet = findViewById(R.id.fragmentLocation) != null; //check if the FrameLayout is loaded

        myList.setAdapter(covidDateListAdaptor = new CovidDateListAdaptor());
        this.loadDataFromDatabase();


        Intent resultByDate = new Intent(this, ResultByDate.class);
        myList.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position,
                                    long id) {
                //create a bundle to pass data to the new fragment
                Bundle dataToPass = new Bundle();
                dataToPass.putString(DATE, dateList.get(position));

                if(isTablet){//both the date list and the details are on the screen
                    dFragment = new CovidResultByDateFragment();//add a covidResultByDateFragment

                    dFragment.setArguments(dataToPass);// pass it a bundle for info
                    getSupportFragmentManager()
                            .beginTransaction()
                            .replace(R.id.fragmentLocation, dFragment)//add a fragment in framelayout
                            .commit();// load the fragment and calls onCreate() in covidResultByDateFragment

                }
                //for phone, can view only the dates list, for details need to go to the result by date activity page.
                else {
                    resultByDate.putExtra("DATE", dateList.get(position));// send data to reault by date activity
                    startActivity(resultByDate);// making the transition
                }
            }
        });
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu items for use in the action bar
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.toolbar_menu, menu);
        //    MenuInflater inflater2 = getMenuInflater();
        // inflater.inflate(R.menu.nagvigationmenu, menu);
        return true;
    }

    private void loadDataFromDatabase()
    {
        //get a database connection:
        DatabaseHandler dbOpener = new DatabaseHandler(this);
        // db = dbOpener.getWritableDatabase(); //This calls onCreate() if you've never built the table before, or onUpgrade if the version here is newer
        db = dbOpener.getReadableDatabase();

        // We want to get all of the columns. Look at MyOpener.java for the definitions:
        // String [] columns = {CovidDataOpener.COL_ID, CovidDataOpener.COL_DATE, CovidDataOpener.COL_CASES, CovidDataOpener.COL_COUNTRY, CovidDataOpener.COL_PROVINCE};
        String [] columns = {DatabaseHandler.COLUMN_DATE};
        //query all the results from the database:
        Cursor results = db.query(true, DatabaseHandler.TABLE_NAME, columns, null, null, null, null, null, null);
        //Now the results object has rows of results that match the query.
        //find the column indices:
        int dateIndex = results.getColumnIndex(DatabaseHandler.COLUMN_DATE);


        //iterate over the results, return true if there is a next item:
        while(results.moveToNext())
        {
            //    long id = results.getLong(idColIndex);
            //    String country = results.getString(countryIndex);
            //    int cases = results.getInt(caseIndex);
            //    String province = results.getString(provinceIndex);
            String date = results.getString(dateIndex);
            //add the new Contact to the array list:
            //String province, int caseNumber,String date, String country, long dId
            //dateList.add(new CovidData(province, cases,date,country,id));
            dateList.add(date);
        }
//        printCursor(results, db.getVersion());
    }
    private class CovidDateListAdaptor extends BaseAdapter {

        @Override
        public int getCount() {
            return dateList.size();
        }

        @Override
        public String getItem(int position) {
            return dateList.get(position);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            LayoutInflater inflater =getLayoutInflater();
            View newView = convertView;
            newView =inflater.inflate(R.layout.covid_adapter_item_layout, parent, false);
            TextView date = newView.findViewById(R.id.dateList);
            date.setText(getItem(position));

            return newView;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }
    }
}